flagOPT                     	  = True
listOfPredicates_super            = []
listOfActions_super               = []
initState_super                   = []
goalState_super                   = []

listOfPredicates_human            = []
listOfActions_human               = []
initState_human                   = []
goalState_human                   = []


